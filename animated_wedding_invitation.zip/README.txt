WEDDING INVITATION TEMPLATE

1. Open index.html in a browser to preview the invitation.
2. Replace BRIDE NAME, GROOM NAME, DD • MONTH • YYYY, venue, city and time.
3. In index.html, change the weddingDate value to the real date/time.
4. Add a royalty-free/owned audio file named music.mp3 in this same folder for background music.
5. For a public link, upload the folder to a static web host such as GitHub Pages, Netlify, or another host.

Included:
- Envelope opening screen
- Background music button
- Falling rose/flower petals
- Fireworks
- Scratch-to-reveal wedding date
- Confetti when the date is revealed
- Countdown timer
- Mobile-friendly layout
